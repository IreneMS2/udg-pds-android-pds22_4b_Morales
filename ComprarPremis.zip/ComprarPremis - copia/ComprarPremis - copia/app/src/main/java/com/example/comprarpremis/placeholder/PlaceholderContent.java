package com.example.comprarpremis.placeholder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 * <p>
 * TODO: Replace all uses of this class before publishing your app.
 */
public class PlaceholderContent {

    /**
     * An array of sample (placeholder) items.
     */
    public static final List<PlaceholderItem> ITEMS = new ArrayList<PlaceholderItem>();

    /**
     * A map of sample (placeholder) items, by ID.
     */
    public static final Map<String, PlaceholderItem> ITEM_MAP = new HashMap<String, PlaceholderItem>();

    // private static final int COUNT = 25; --> Nosaltres inicialment tindrem 3 premis inicialment

    static {
        // Add some sample items.
            addItem(new PlaceholderItem("1", "Secretlab TITAN Evo 2022", "Regular size, Yasuo Special Edition", "yasuo.png", "500 UdG Coins"));
            addItem(new PlaceholderItem("2", "Auriculars Astro A50", "Auriculars inalambrics " +
                    "amb micròfon i estació base, Color: Black Grey", "a50.png", "350 UdG Coins"));
            addItem(new PlaceholderItem("3", "Ratolí Gaming Logitech", "Logitech Pro X Superlight Ratolí Gaming Inalàmbric 25.600DPI Rosa", "logitech.png", "130 UdG Coins"));
    }

    private static void addItem(PlaceholderItem item) {
        ITEMS.add(item);
        ITEM_MAP.put(item.id, item);
    }

    /*private static PlaceholderItem createPlaceholderItem(int position) {
        return new PlaceholderItem(String.valueOf(position), "Item " + position, makeDetails(position), "imatgePremi", "preuPremi");
    }*/

    private static String makeDetails(int position) { ///aixo sha de cridar en algun lloc
        StringBuilder builder = new StringBuilder();
        builder.append("Details about Item: ").append(position);
        for (int i = 0; i < position; i++) {
            builder.append("\nMore details information here.");
        }
        return builder.toString();
    }

    /**
     * A placeholder item representing a piece of content.
     */
    public static class PlaceholderItem {
        public final String id;
        public final String nomPremi;
        public final String detallsPremi;
        public final String imatgePremi;
        public final String preuPremi;

        public PlaceholderItem(String id, String nomPremi, String detallsPremi, String imatgePremi, String preuPremi) {
            this.id = id;
            this.nomPremi = nomPremi;
            this.detallsPremi = detallsPremi;
            this.imatgePremi = imatgePremi;
            this.preuPremi = preuPremi;
        }

        @Override
        public String toString() {
            return nomPremi;
        }
    }
}