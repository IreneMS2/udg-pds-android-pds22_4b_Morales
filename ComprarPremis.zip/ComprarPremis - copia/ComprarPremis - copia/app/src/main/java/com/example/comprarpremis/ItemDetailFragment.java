package com.example.comprarpremis;

import android.content.ClipData;
import android.os.Bundle;
import android.view.DragEvent;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.example.comprarpremis.placeholder.PlaceholderContent;
import com.example.comprarpremis.databinding.FragmentItemDetailBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

/**
 * A fragment representing a single Item detail screen.
 * This fragment is either contained in a {@link ItemListFragment}
 * in two-pane mode (on larger screen devices) or self-contained
 * on handsets.
 */
public class ItemDetailFragment extends Fragment {

    /**
     * The fragment argument representing the item ID that this fragment
     * represents.
     */
    public static final String ARG_ITEM_ID = "item_id";

    /**
     * The placeholder content this fragment is presenting.
     */
    private PlaceholderContent.PlaceholderItem mItem;
    private CollapsingToolbarLayout mToolbarLayout;
   // private TextView mTextView; M'agradaria que sortís el nom a dalt de tot com a titol pero no se perque no puc
    private TextView mTextView2;
    private ImageView mImageView;
    private FloatingActionButton mFab;

    private final View.OnDragListener dragListener = (v, event) -> {
        if (event.getAction() == DragEvent.ACTION_DROP) {
            ClipData.Item clipDataItem = event.getClipData().getItemAt(0);
            mItem = PlaceholderContent.ITEM_MAP.get(clipDataItem.getText().toString());
            updateContent();
        }
        return true;
    };
    private FragmentItemDetailBinding binding;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public ItemDetailFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments().containsKey(ARG_ITEM_ID)) {
            // Load the placeholder content specified by the fragment
            // arguments. In a real-world scenario, use a Loader
            // to load content from a content provider.
            mItem = PlaceholderContent.ITEM_MAP.get(getArguments().getString(ARG_ITEM_ID));
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding = FragmentItemDetailBinding.inflate(inflater, container, false);
        View rootView = binding.getRoot();

        mToolbarLayout = rootView.findViewById(R.id.toolbar_layout);
     //   mTextView = rootView.findViewById(R.id.item_name);
        mTextView2 = binding.itemDetail;
        mImageView = (rootView.findViewById(R.id.item_image));
        mFab = rootView.findViewById(R.id.floatingActionButton);

        mFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Actualment el producte està fora de stock",Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        if (mToolbarLayout != null) {
               // mTextView.setText(mItem.nomPremi); //No puc fer que aparegui el nom a sobre de la foto del premi
                mTextView2.setText(mItem.detallsPremi);
        }

        if ("Secretlab TITAN Evo 2022".equals(mItem.nomPremi)) {
            mImageView.setImageResource(R.drawable.yasuo);

        } else if ("Auriculars Astro A50".equals(mItem.nomPremi)) {
            mImageView.setImageResource(R.drawable.a50);

        } else if ("Ratolí Gaming Logitech".equals(mItem.nomPremi)) {
            mImageView.setImageResource(R.drawable.logitech);
        } else {
            mImageView.setImageResource(R.drawable.yasuo);
        }
        // Show the placeholder content as text in a TextView & in the toolbar if available.
        updateContent();
      //
        rootView.setOnDragListener(dragListener);
        return rootView;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void updateContent() {
        if(mItem != null)
            mToolbarLayout.setTitle(mItem.nomPremi);
    }
}